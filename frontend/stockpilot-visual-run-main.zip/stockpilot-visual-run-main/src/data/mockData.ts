import { Flight, FlightDetails } from "@/types/flight";

export const mockFlights: Flight[] = [
  {
    flightNumber: "AV315",
    destination: "Santiago (SCL)",
    departureTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
  },
  {
    flightNumber: "AV782",
    destination: "Buenos Aires (EZE)",
    departureTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // 4 hours
  },
  {
    flightNumber: "AV501",
    destination: "Lima (LIM)",
    departureTime: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(), // 5 hours
  },
  {
    flightNumber: "AV423",
    destination: "México (MEX)",
    departureTime: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(), // 6 hours
  },
  {
    flightNumber: "AV892",
    destination: "Madrid (MAD)",
    departureTime: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(), // 8 hours
  },
  {
    flightNumber: "AV654",
    destination: "Miami (MIA)",
    departureTime: new Date(Date.now() + 10 * 60 * 60 * 1000).toISOString(), // 10 hours
  },
];

export const mockFlightDetails: Record<string, FlightDetails> = {
  AV315: {
    flightNumber: "AV315",
    destination: "Santiago (SCL)",
    departureTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Sandwich Jamón y Queso",
        category: "Comida Fría",
        categoryQuantity: 45,
        priorityLot: "K",
      },
      {
        productName: "Ensalada César",
        category: "Comida Fría",
        categoryQuantity: 32,
        priorityLot: "L",
      },
      {
        productName: "Agua Mineral 500ml",
        category: "Bebidas",
        categoryQuantity: 120,
        priorityLot: "M",
      },
      {
        productName: "Jugo de Naranja",
        category: "Bebidas",
        categoryQuantity: 80,
        priorityLot: "N",
      },
      {
        productName: "Café Premium",
        category: "Bebidas Calientes",
        categoryQuantity: 60,
        priorityLot: "P",
      },
      {
        productName: "Galletas Chocolate",
        category: "Snacks",
        categoryQuantity: 90,
        priorityLot: "Q",
      },
    ],
  },
  AV782: {
    flightNumber: "AV782",
    destination: "Buenos Aires (EZE)",
    departureTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Wrap Pollo y Vegetales",
        category: "Comida Fría",
        categoryQuantity: 38,
        priorityLot: "A",
      },
      {
        productName: "Yogurt Natural",
        category: "Lácteos",
        categoryQuantity: 55,
        priorityLot: "B",
      },
      {
        productName: "Coca-Cola",
        category: "Bebidas",
        categoryQuantity: 100,
        priorityLot: "C",
      },
      {
        productName: "Té Verde",
        category: "Bebidas Calientes",
        categoryQuantity: 40,
        priorityLot: "D",
      },
    ],
  },
  AV501: {
    flightNumber: "AV501",
    destination: "Lima (LIM)",
    departureTime: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Croissant Relleno",
        category: "Panadería",
        categoryQuantity: 50,
        priorityLot: "E",
      },
      {
        productName: "Fruta Fresca Mix",
        category: "Snacks Saludables",
        categoryQuantity: 42,
        priorityLot: "F",
      },
      {
        productName: "Sprite",
        category: "Bebidas",
        categoryQuantity: 85,
        priorityLot: "G",
      },
      {
        productName: "Café Americano",
        category: "Bebidas Calientes",
        categoryQuantity: 70,
        priorityLot: "H",
      },
      {
        productName: "Papas Fritas",
        category: "Snacks",
        categoryQuantity: 65,
        priorityLot: "I",
      },
    ],
  },
  AV423: {
    flightNumber: "AV423",
    destination: "México (MEX)",
    departureTime: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Burrito de Pollo",
        category: "Comida Caliente",
        categoryQuantity: 48,
        priorityLot: "R",
      },
      {
        productName: "Cerveza Premium",
        category: "Bebidas Alcohólicas",
        categoryQuantity: 95,
        priorityLot: "S",
      },
      {
        productName: "Vino Tinto",
        category: "Bebidas Alcohólicas",
        categoryQuantity: 30,
        priorityLot: "T",
      },
    ],
  },
  AV892: {
    flightNumber: "AV892",
    destination: "Madrid (MAD)",
    departureTime: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Pasta Carbonara",
        category: "Comida Caliente",
        categoryQuantity: 60,
        priorityLot: "U",
      },
      {
        productName: "Pan Artesanal",
        category: "Panadería",
        categoryQuantity: 75,
        priorityLot: "V",
      },
      {
        productName: "Vino Blanco",
        category: "Bebidas Alcohólicas",
        categoryQuantity: 40,
        priorityLot: "W",
      },
      {
        productName: "Helado Premium",
        category: "Postres",
        categoryQuantity: 50,
        priorityLot: "X",
      },
    ],
  },
  AV654: {
    flightNumber: "AV654",
    destination: "Miami (MIA)",
    departureTime: new Date(Date.now() + 10 * 60 * 60 * 1000).toISOString(),
    products: [
      {
        productName: "Hamburguesa Gourmet",
        category: "Comida Caliente",
        categoryQuantity: 52,
        priorityLot: "Y",
      },
      {
        productName: "Smoothie de Frutas",
        category: "Bebidas",
        categoryQuantity: 68,
        priorityLot: "Z",
      },
      {
        productName: "Brownies",
        category: "Postres",
        categoryQuantity: 45,
        priorityLot: "AA",
      },
    ],
  },
};
